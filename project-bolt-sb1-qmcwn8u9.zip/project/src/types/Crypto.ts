export interface CryptoData {
  name: string;
  symbol: string;
  price_trend: 'rising' | 'stable' | 'falling';
  market_cap: 'high' | 'medium' | 'low';
  energy_use: 'high' | 'medium' | 'low';
  sustainability_score: number;
  current_price: number;
  description: string;
}

export interface ChatMessage {
  id: string;
  text: string;
  sender: 'user' | 'bot';
  timestamp: Date;
  recommendations?: CryptoData[];
}

export type QueryType = 
  | 'sustainable'
  | 'profitable' 
  | 'trending'
  | 'safe'
  | 'general'
  | 'greeting'
  | 'help';