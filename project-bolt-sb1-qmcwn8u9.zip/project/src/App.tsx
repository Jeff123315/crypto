import React from 'react';
import { CryptoBuddyApp } from './components/CryptoBuddyApp';

function App() {
  return <CryptoBuddyApp />;
}

export default App;