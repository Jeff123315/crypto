import { CryptoData, QueryType } from '../types/Crypto';
import { cryptoDatabase } from '../data/cryptoDatabase';

export class CryptoBuddyAI {
  private cryptos: CryptoData[];

  constructor() {
    this.cryptos = Object.values(cryptoDatabase);
  }

  analyzeQuery(query: string): QueryType {
    const lowerQuery = query.toLowerCase();
    
    if (lowerQuery.includes('hello') || lowerQuery.includes('hi') || lowerQuery.includes('hey')) {
      return 'greeting';
    }
    if (lowerQuery.includes('help') || lowerQuery.includes('what can you do')) {
      return 'help';
    }
    if (lowerQuery.includes('sustainable') || lowerQuery.includes('eco') || lowerQuery.includes('green') || lowerQuery.includes('environment')) {
      return 'sustainable';
    }
    if (lowerQuery.includes('profit') || lowerQuery.includes('money') || lowerQuery.includes('gain') || lowerQuery.includes('return')) {
      return 'profitable';
    }
    if (lowerQuery.includes('trend') || lowerQuery.includes('rising') || lowerQuery.includes('growing') || lowerQuery.includes('hot')) {
      return 'trending';
    }
    if (lowerQuery.includes('safe') || lowerQuery.includes('stable') || lowerQuery.includes('secure') || lowerQuery.includes('reliable')) {
      return 'safe';
    }
    
    return 'general';
  }

  generateResponse(query: string): { message: string; recommendations: CryptoData[] } {
    const queryType = this.analyzeQuery(query);
    
    switch (queryType) {
      case 'greeting':
        return {
          message: "Hey there! 👋 I'm CryptoBuddy, your AI-powered crypto investment advisor! I analyze cryptocurrencies based on profitability and sustainability to help you make informed decisions. What would you like to know about crypto investments?",
          recommendations: []
        };
        
      case 'help':
        return {
          message: "I can help you with crypto investment advice! Try asking me:\n\n• 'What's the most sustainable crypto?'\n• 'Which coins are trending up?'\n• 'Show me profitable investments'\n• 'What's a safe crypto to buy?'\n\nI analyze coins based on price trends, market cap, energy efficiency, and sustainability scores! 🚀",
          recommendations: []
        };
        
      case 'sustainable':
        const sustainableCryptos = this.cryptos
          .filter(crypto => crypto.sustainability_score >= 7)
          .sort((a, b) => b.sustainability_score - a.sustainability_score);
        
        return {
          message: `🌱 Here are the most sustainable cryptocurrencies! These coins have excellent environmental credentials with low energy consumption and high sustainability scores:`,
          recommendations: sustainableCryptos
        };
        
      case 'profitable':
        const profitableCryptos = this.cryptos
          .filter(crypto => crypto.price_trend === 'rising' && (crypto.market_cap === 'high' || crypto.market_cap === 'medium'))
          .sort((a, b) => {
            const scoreA = (a.market_cap === 'high' ? 3 : 2) + (a.price_trend === 'rising' ? 2 : 0);
            const scoreB = (b.market_cap === 'high' ? 3 : 2) + (b.price_trend === 'rising' ? 2 : 0);
            return scoreB - scoreA;
          });
        
        return {
          message: `💰 These cryptocurrencies show strong profit potential with rising price trends and solid market positions:`,
          recommendations: profitableCryptos
        };
        
      case 'trending':
        const trendingCryptos = this.cryptos
          .filter(crypto => crypto.price_trend === 'rising')
          .sort((a, b) => {
            const marketCapScore = { high: 3, medium: 2, low: 1 };
            return marketCapScore[b.market_cap] - marketCapScore[a.market_cap];
          });
        
        return {
          message: `🚀 These cryptocurrencies are currently trending upward with positive price momentum:`,
          recommendations: trendingCryptos
        };
        
      case 'safe':
        const safeCryptos = this.cryptos
          .filter(crypto => crypto.market_cap === 'high' || (crypto.market_cap === 'medium' && crypto.sustainability_score >= 6))
          .sort((a, b) => {
            const safetyScore = (crypto: CryptoData) => {
              let score = 0;
              if (crypto.market_cap === 'high') score += 3;
              if (crypto.market_cap === 'medium') score += 2;
              if (crypto.sustainability_score >= 7) score += 2;
              if (crypto.price_trend === 'stable') score += 1;
              return score;
            };
            return safetyScore(b) - safetyScore(a);
          });
        
        return {
          message: `🛡️ These are relatively safer cryptocurrency investments with established market presence and good fundamentals:`,
          recommendations: safeCryptos
        };
        
      default:
        const topCryptos = this.cryptos
          .sort((a, b) => {
            const overallScore = (crypto: CryptoData) => {
              let score = 0;
              if (crypto.price_trend === 'rising') score += 3;
              if (crypto.price_trend === 'stable') score += 1;
              if (crypto.market_cap === 'high') score += 3;
              if (crypto.market_cap === 'medium') score += 2;
              score += crypto.sustainability_score * 0.5;
              return score;
            };
            return overallScore(b) - overallScore(a);
          })
          .slice(0, 3);
        
        return {
          message: `🤖 Based on my analysis, here are some well-balanced cryptocurrency recommendations considering both profitability and sustainability:`,
          recommendations: topCryptos
        };
    }
  }

  getDisclaimer(): string {
    return "⚠️ Important: Cryptocurrency investments are highly volatile and risky. This advice is for educational purposes only. Always do your own research and never invest more than you can afford to lose!";
  }
}