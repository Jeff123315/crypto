import React from 'react';
import { TrendingUp, TrendingDown, Minus, Leaf, Zap, DollarSign } from 'lucide-react';
import { CryptoData } from '../types/Crypto';

interface CryptoCardProps {
  crypto: CryptoData;
}

export const CryptoCard: React.FC<CryptoCardProps> = ({ crypto }) => {
  const getTrendIcon = () => {
    switch (crypto.price_trend) {
      case 'rising':
        return <TrendingUp size={16} className="text-green-600" />;
      case 'falling':
        return <TrendingDown size={16} className="text-red-600" />;
      default:
        return <Minus size={16} className="text-gray-600" />;
    }
  };

  const getTrendColor = () => {
    switch (crypto.price_trend) {
      case 'rising':
        return 'text-green-600 bg-green-50';
      case 'falling':
        return 'text-red-600 bg-red-50';
      default:
        return 'text-gray-600 bg-gray-50';
    }
  };

  const getSustainabilityColor = () => {
    if (crypto.sustainability_score >= 7) return 'text-green-600 bg-green-50';
    if (crypto.sustainability_score >= 5) return 'text-yellow-600 bg-yellow-50';
    return 'text-red-600 bg-red-50';
  };

  const getMarketCapColor = () => {
    switch (crypto.market_cap) {
      case 'high':
        return 'text-blue-600 bg-blue-50';
      case 'medium':
        return 'text-purple-600 bg-purple-50';
      default:
        return 'text-gray-600 bg-gray-50';
    }
  };

  return (
    <div className="bg-white border border-gray-200 rounded-xl p-4 hover:shadow-md transition-shadow duration-200">
      <div className="flex items-start justify-between mb-3">
        <div>
          <h3 className="font-bold text-lg text-gray-900">{crypto.name}</h3>
          <p className="text-sm text-gray-500">{crypto.symbol}</p>
        </div>
        <div className="text-right">
          <p className="font-semibold text-gray-900">${crypto.current_price.toLocaleString()}</p>
          <div className={`flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium ${getTrendColor()}`}>
            {getTrendIcon()}
            {crypto.price_trend}
          </div>
        </div>
      </div>
      
      <p className="text-sm text-gray-600 mb-4">{crypto.description}</p>
      
      <div className="grid grid-cols-3 gap-2">
        <div className={`flex items-center gap-1 px-2 py-1 rounded-lg text-xs font-medium ${getMarketCapColor()}`}>
          <DollarSign size={12} />
          {crypto.market_cap} cap
        </div>
        
        <div className={`flex items-center gap-1 px-2 py-1 rounded-lg text-xs font-medium ${
          crypto.energy_use === 'low' ? 'text-green-600 bg-green-50' :
          crypto.energy_use === 'medium' ? 'text-yellow-600 bg-yellow-50' :
          'text-red-600 bg-red-50'
        }`}>
          <Zap size={12} />
          {crypto.energy_use} energy
        </div>
        
        <div className={`flex items-center gap-1 px-2 py-1 rounded-lg text-xs font-medium ${getSustainabilityColor()}`}>
          <Leaf size={12} />
          {crypto.sustainability_score}/10
        </div>
      </div>
    </div>
  );
};