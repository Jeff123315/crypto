import React from 'react';
import { TodoFilter as TodoFilterType } from '../types/Todo';

interface TodoFilterProps {
  currentFilter: TodoFilterType;
  onFilterChange: (filter: TodoFilterType) => void;
  stats: {
    total: number;
    active: number;
    completed: number;
  };
}

export const TodoFilter: React.FC<TodoFilterProps> = ({ currentFilter, onFilterChange, stats }) => {
  const filters: { key: TodoFilterType; label: string; count: number }[] = [
    { key: 'all', label: 'All', count: stats.total },
    { key: 'active', label: 'Active', count: stats.active },
    { key: 'completed', label: 'Completed', count: stats.completed },
  ];

  return (
    <div className="flex flex-wrap gap-2 mb-6">
      {filters.map(filter => (
        <button
          key={filter.key}
          onClick={() => onFilterChange(filter.key)}
          className={`px-4 py-2 rounded-lg font-medium transition-all duration-200 ${
            currentFilter === filter.key
              ? 'bg-blue-600 text-white shadow-md'
              : 'bg-white text-gray-600 hover:bg-gray-50 border border-gray-200'
          }`}
        >
          {filter.label}
          <span className={`ml-2 px-2 py-1 rounded-full text-xs ${
            currentFilter === filter.key
              ? 'bg-blue-500 text-white'
              : 'bg-gray-100 text-gray-500'
          }`}>
            {filter.count}
          </span>
        </button>
      ))}
    </div>
  );
};