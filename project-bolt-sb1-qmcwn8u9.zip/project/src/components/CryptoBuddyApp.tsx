import React, { useState, useRef, useEffect } from 'react';
import { Bot, AlertTriangle, TrendingUp } from 'lucide-react';
import { ChatMessage as ChatMessageType } from '../types/Crypto';
import { CryptoBuddyAI } from '../utils/chatbotLogic';
import { ChatMessage } from './ChatMessage';
import { ChatInput } from './ChatInput';

export const CryptoBuddyApp: React.FC = () => {
  const [messages, setMessages] = useState<ChatMessageType[]>([]);
  const [isTyping, setIsTyping] = useState(false);
  const chatContainerRef = useRef<HTMLDivElement>(null);
  const cryptoBuddy = useRef(new CryptoBuddyAI());

  useEffect(() => {
    // Initial greeting message
    const welcomeMessage: ChatMessageType = {
      id: crypto.randomUUID(),
      text: "Hey there! 👋 I'm CryptoBuddy, your AI-powered crypto investment advisor! I analyze cryptocurrencies based on profitability and sustainability to help you make informed decisions. What would you like to know about crypto investments?",
      sender: 'bot',
      timestamp: new Date(),
      recommendations: []
    };
    setMessages([welcomeMessage]);
  }, []);

  useEffect(() => {
    if (chatContainerRef.current) {
      chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
    }
  }, [messages, isTyping]);

  const handleSendMessage = async (messageText: string) => {
    // Add user message
    const userMessage: ChatMessageType = {
      id: crypto.randomUUID(),
      text: messageText,
      sender: 'user',
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setIsTyping(true);

    // Simulate thinking time
    await new Promise(resolve => setTimeout(resolve, 1000 + Math.random() * 1000));

    // Generate bot response
    const response = cryptoBuddy.current.generateResponse(messageText);
    
    const botMessage: ChatMessageType = {
      id: crypto.randomUUID(),
      text: response.message,
      sender: 'bot',
      timestamp: new Date(),
      recommendations: response.recommendations
    };

    setMessages(prev => [...prev, botMessage]);

    // Add disclaimer for investment advice
    if (response.recommendations.length > 0) {
      await new Promise(resolve => setTimeout(resolve, 500));
      
      const disclaimerMessage: ChatMessageType = {
        id: crypto.randomUUID(),
        text: cryptoBuddy.current.getDisclaimer(),
        sender: 'bot',
        timestamp: new Date()
      };
      
      setMessages(prev => [...prev, disclaimerMessage]);
    }

    setIsTyping(false);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      <div className="max-w-4xl mx-auto flex flex-col h-screen">
        {/* Header */}
        <div className="bg-white border-b border-gray-200 px-6 py-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center">
              <Bot size={24} className="text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">CryptoBuddy</h1>
              <p className="text-gray-600">AI Cryptocurrency Investment Advisor</p>
            </div>
            <div className="ml-auto flex items-center gap-2 px-3 py-1 bg-green-100 text-green-800 rounded-full text-sm font-medium">
              <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
              Online
            </div>
          </div>
        </div>

        {/* Chat Messages */}
        <div 
          ref={chatContainerRef}
          className="flex-1 overflow-y-auto px-6 py-6 space-y-4"
        >
          {messages.map(message => (
            <ChatMessage key={message.id} message={message} />
          ))}
          
          {isTyping && (
            <div className="flex gap-3 justify-start mb-6">
              <div className="flex-shrink-0 w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center">
                <Bot size={20} className="text-white" />
              </div>
              <div className="bg-white border border-gray-200 rounded-2xl px-4 py-3">
                <div className="flex gap-1">
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Disclaimer Banner */}
        <div className="bg-amber-50 border-t border-amber-200 px-6 py-3">
          <div className="flex items-center gap-2 text-amber-800">
            <AlertTriangle size={16} />
            <p className="text-sm">
              <strong>Risk Warning:</strong> Cryptocurrency investments are highly volatile. This is educational content only - always do your own research!
            </p>
          </div>
        </div>

        {/* Chat Input */}
        <ChatInput onSendMessage={handleSendMessage} disabled={isTyping} />
      </div>
    </div>
  );
};