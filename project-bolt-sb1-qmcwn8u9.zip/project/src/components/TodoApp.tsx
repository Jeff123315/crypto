import React from 'react';
import { CheckSquare, Trash2 } from 'lucide-react';
import { useTodos } from '../hooks/useTodos';
import { AddTodoForm } from './AddTodoForm';
import { TodoItem } from './TodoItem';
import { TodoFilter } from './TodoFilter';

export const TodoApp: React.FC = () => {
  const {
    todos,
    filter,
    setFilter,
    addTodo,
    updateTodo,
    deleteTodo,
    clearCompleted,
    stats,
  } = useTodos();

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 py-8 px-4">
      <div className="max-w-2xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="flex items-center justify-center gap-3 mb-4">
            <CheckSquare size={40} className="text-blue-600" />
            <h1 className="text-4xl font-bold text-gray-800">TodoFlow</h1>
          </div>
          <p className="text-gray-600 text-lg">Organize your tasks with style</p>
        </div>

        {/* Add Todo Form */}
        <AddTodoForm onAdd={addTodo} />

        {/* Stats & Filters */}
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
          <TodoFilter
            currentFilter={filter}
            onFilterChange={setFilter}
            stats={stats}
          />
          
          {stats.completed > 0 && (
            <button
              onClick={clearCompleted}
              className="flex items-center gap-2 px-4 py-2 text-red-600 hover:text-red-700 hover:bg-red-50 rounded-lg transition-colors duration-200 border border-red-200 hover:border-red-300"
            >
              <Trash2 size={16} />
              Clear Completed
            </button>
          )}
        </div>

        {/* Todo List */}
        <div className="space-y-3">
          {todos.length === 0 ? (
            <div className="text-center py-12">
              <div className="w-24 h-24 mx-auto mb-4 bg-gray-100 rounded-full flex items-center justify-center">
                <CheckSquare size={40} className="text-gray-400" />
              </div>
              <h3 className="text-xl font-medium text-gray-500 mb-2">
                {filter === 'completed'
                  ? 'No completed tasks yet'
                  : filter === 'active'
                  ? 'No active tasks'
                  : 'No tasks yet'}
              </h3>
              <p className="text-gray-400">
                {filter === 'all'
                  ? 'Add your first task above to get started!'
                  : `Switch to "All" to see your other tasks`}
              </p>
            </div>
          ) : (
            todos.map(todo => (
              <TodoItem
                key={todo.id}
                todo={todo}
                onUpdate={updateTodo}
                onDelete={deleteTodo}
              />
            ))
          )}
        </div>

        {/* Footer */}
        {stats.total > 0 && (
          <div className="mt-8 pt-6 border-t border-gray-200 text-center text-gray-500">
            <p>
              {stats.active} of {stats.total} tasks remaining
            </p>
          </div>
        )}
      </div>
    </div>
  );
};