import { CryptoData } from '../types/Crypto';

export const cryptoDatabase: Record<string, CryptoData> = {
  "Bitcoin": {
    name: "Bitcoin",
    symbol: "BTC",
    price_trend: "rising",
    market_cap: "high",
    energy_use: "high",
    sustainability_score: 3,
    current_price: 43250,
    description: "The original cryptocurrency with the largest market cap but high energy consumption."
  },
  "Ethereum": {
    name: "Ethereum",
    symbol: "ETH",
    price_trend: "stable",
    market_cap: "high",
    energy_use: "medium",
    sustainability_score: 6,
    current_price: 2650,
    description: "Smart contract platform with improved energy efficiency after Ethereum 2.0 upgrade."
  },
  "Cardano": {
    name: "Cardano",
    symbol: "ADA",
    price_trend: "rising",
    market_cap: "medium",
    energy_use: "low",
    sustainability_score: 8,
    current_price: 0.48,
    description: "Proof-of-stake blockchain focused on sustainability and academic research."
  },
  "Solana": {
    name: "Solana",
    symbol: "SOL",
    price_trend: "rising",
    market_cap: "medium",
    energy_use: "low",
    sustainability_score: 7,
    current_price: 98.50,
    description: "High-performance blockchain with low energy consumption and fast transactions."
  },
  "Polygon": {
    name: "Polygon",
    symbol: "MATIC",
    price_trend: "stable",
    market_cap: "medium",
    energy_use: "low",
    sustainability_score: 8,
    current_price: 0.85,
    description: "Layer 2 scaling solution for Ethereum with excellent sustainability metrics."
  },
  "Chainlink": {
    name: "Chainlink",
    symbol: "LINK",
    price_trend: "stable",
    market_cap: "medium",
    energy_use: "low",
    sustainability_score: 7,
    current_price: 14.75,
    description: "Decentralized oracle network connecting smart contracts to real-world data."
  }
};